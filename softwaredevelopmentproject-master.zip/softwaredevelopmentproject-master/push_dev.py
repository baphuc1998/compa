import os
os.system('git push dev master')
