# Glad-Food
Order and Restaurant Management Supporting System
