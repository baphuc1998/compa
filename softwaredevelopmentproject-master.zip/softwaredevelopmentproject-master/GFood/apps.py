from django.apps import AppConfig


class GfoodConfig(AppConfig):
    name = 'GFood'
