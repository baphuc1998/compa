http://127.0.0.1:8000/api/user/


Admin:
Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNTY4NTc5NDI5LCJqdGkiOiI3ZmI0NDc2MzM2NzA0MGQ4ODRhMmJhNjRhZTU3MGMzMyIsInVzZXJfaWQiOjEsInR5cGUiOiJhZG1pbiJ9.72VFuxJJwH2TT44mGP9rR-V0fga__B7gjSCzMlm6gwc

Merchant: 0001
Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNTY4NTg4NjAxLCJqdGkiOiJlMGViYTc3ZGQ4YzA0MTM2OTBlMGYzZjZhOTk4YWRjNiIsInVzZXJfaWQiOjMsInR5cGUiOiJtZXJjaGFudCJ9.5zG7M65YQYtRohbfk8hRz6VfrU7zcuiuLib20YEVztY

{
    id : 1
    product: {
        id : 2
        name : aa
    }
}